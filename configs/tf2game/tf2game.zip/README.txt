put all .cfg files in tf/cfg/user (e.g. "C:\Program Files (x86)\Steam\steamapps\common\Team Fortress 2\tf\cfg\user\aliases.cfg")
mastercomfig-ultra-preset.vpk goes in tf/custom